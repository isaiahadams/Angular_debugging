/**
 * AlertInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package _2._1.cap.emergency.tc.names.oasis;

public class AlertInfo  implements java.io.Serializable {
    private org.apache.axis.types.Language language;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoCategory[] category;

    private java.lang.String event;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoResponseType[] responseType;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoUrgency urgency;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoSeverity severity;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoCertainty certainty;

    private java.lang.String audience;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoEventCode[] eventCode;

    private java.util.Calendar effective;

    private java.util.Calendar onset;

    private java.util.Calendar expires;

    private java.lang.String senderName;

    private java.lang.String headline;

    private java.lang.String description;

    private java.lang.String instruction;

    private org.apache.axis.types.URI web;

    private java.lang.String contact;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoParameter[] parameter;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoResource[] resource;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoArea[] area;

    public AlertInfo() {
    }

    public AlertInfo(
           org.apache.axis.types.Language language,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoCategory[] category,
           java.lang.String event,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoResponseType[] responseType,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoUrgency urgency,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoSeverity severity,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoCertainty certainty,
           java.lang.String audience,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoEventCode[] eventCode,
           java.util.Calendar effective,
           java.util.Calendar onset,
           java.util.Calendar expires,
           java.lang.String senderName,
           java.lang.String headline,
           java.lang.String description,
           java.lang.String instruction,
           org.apache.axis.types.URI web,
           java.lang.String contact,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoParameter[] parameter,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoResource[] resource,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoArea[] area) {
           this.language = language;
           this.category = category;
           this.event = event;
           this.responseType = responseType;
           this.urgency = urgency;
           this.severity = severity;
           this.certainty = certainty;
           this.audience = audience;
           this.eventCode = eventCode;
           this.effective = effective;
           this.onset = onset;
           this.expires = expires;
           this.senderName = senderName;
           this.headline = headline;
           this.description = description;
           this.instruction = instruction;
           this.web = web;
           this.contact = contact;
           this.parameter = parameter;
           this.resource = resource;
           this.area = area;
    }


    /**
     * Gets the language value for this AlertInfo.
     * 
     * @return language
     */
    public org.apache.axis.types.Language getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this AlertInfo.
     * 
     * @param language
     */
    public void setLanguage(org.apache.axis.types.Language language) {
        this.language = language;
    }


    /**
     * Gets the category value for this AlertInfo.
     * 
     * @return category
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoCategory[] getCategory() {
        return category;
    }


    /**
     * Sets the category value for this AlertInfo.
     * 
     * @param category
     */
    public void setCategory(_2._1.cap.emergency.tc.names.oasis.AlertInfoCategory[] category) {
        this.category = category;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfoCategory getCategory(int i) {
        return this.category[i];
    }

    public void setCategory(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfoCategory _value) {
        this.category[i] = _value;
    }


    /**
     * Gets the event value for this AlertInfo.
     * 
     * @return event
     */
    public java.lang.String getEvent() {
        return event;
    }


    /**
     * Sets the event value for this AlertInfo.
     * 
     * @param event
     */
    public void setEvent(java.lang.String event) {
        this.event = event;
    }


    /**
     * Gets the responseType value for this AlertInfo.
     * 
     * @return responseType
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoResponseType[] getResponseType() {
        return responseType;
    }


    /**
     * Sets the responseType value for this AlertInfo.
     * 
     * @param responseType
     */
    public void setResponseType(_2._1.cap.emergency.tc.names.oasis.AlertInfoResponseType[] responseType) {
        this.responseType = responseType;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfoResponseType getResponseType(int i) {
        return this.responseType[i];
    }

    public void setResponseType(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfoResponseType _value) {
        this.responseType[i] = _value;
    }


    /**
     * Gets the urgency value for this AlertInfo.
     * 
     * @return urgency
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoUrgency getUrgency() {
        return urgency;
    }


    /**
     * Sets the urgency value for this AlertInfo.
     * 
     * @param urgency
     */
    public void setUrgency(_2._1.cap.emergency.tc.names.oasis.AlertInfoUrgency urgency) {
        this.urgency = urgency;
    }


    /**
     * Gets the severity value for this AlertInfo.
     * 
     * @return severity
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoSeverity getSeverity() {
        return severity;
    }


    /**
     * Sets the severity value for this AlertInfo.
     * 
     * @param severity
     */
    public void setSeverity(_2._1.cap.emergency.tc.names.oasis.AlertInfoSeverity severity) {
        this.severity = severity;
    }


    /**
     * Gets the certainty value for this AlertInfo.
     * 
     * @return certainty
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoCertainty getCertainty() {
        return certainty;
    }


    /**
     * Sets the certainty value for this AlertInfo.
     * 
     * @param certainty
     */
    public void setCertainty(_2._1.cap.emergency.tc.names.oasis.AlertInfoCertainty certainty) {
        this.certainty = certainty;
    }


    /**
     * Gets the audience value for this AlertInfo.
     * 
     * @return audience
     */
    public java.lang.String getAudience() {
        return audience;
    }


    /**
     * Sets the audience value for this AlertInfo.
     * 
     * @param audience
     */
    public void setAudience(java.lang.String audience) {
        this.audience = audience;
    }


    /**
     * Gets the eventCode value for this AlertInfo.
     * 
     * @return eventCode
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoEventCode[] getEventCode() {
        return eventCode;
    }


    /**
     * Sets the eventCode value for this AlertInfo.
     * 
     * @param eventCode
     */
    public void setEventCode(_2._1.cap.emergency.tc.names.oasis.AlertInfoEventCode[] eventCode) {
        this.eventCode = eventCode;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfoEventCode getEventCode(int i) {
        return this.eventCode[i];
    }

    public void setEventCode(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfoEventCode _value) {
        this.eventCode[i] = _value;
    }


    /**
     * Gets the effective value for this AlertInfo.
     * 
     * @return effective
     */
    public java.util.Calendar getEffective() {
        return effective;
    }


    /**
     * Sets the effective value for this AlertInfo.
     * 
     * @param effective
     */
    public void setEffective(java.util.Calendar effective) {
        this.effective = effective;
    }


    /**
     * Gets the onset value for this AlertInfo.
     * 
     * @return onset
     */
    public java.util.Calendar getOnset() {
        return onset;
    }


    /**
     * Sets the onset value for this AlertInfo.
     * 
     * @param onset
     */
    public void setOnset(java.util.Calendar onset) {
        this.onset = onset;
    }


    /**
     * Gets the expires value for this AlertInfo.
     * 
     * @return expires
     */
    public java.util.Calendar getExpires() {
        return expires;
    }


    /**
     * Sets the expires value for this AlertInfo.
     * 
     * @param expires
     */
    public void setExpires(java.util.Calendar expires) {
        this.expires = expires;
    }


    /**
     * Gets the senderName value for this AlertInfo.
     * 
     * @return senderName
     */
    public java.lang.String getSenderName() {
        return senderName;
    }


    /**
     * Sets the senderName value for this AlertInfo.
     * 
     * @param senderName
     */
    public void setSenderName(java.lang.String senderName) {
        this.senderName = senderName;
    }


    /**
     * Gets the headline value for this AlertInfo.
     * 
     * @return headline
     */
    public java.lang.String getHeadline() {
        return headline;
    }


    /**
     * Sets the headline value for this AlertInfo.
     * 
     * @param headline
     */
    public void setHeadline(java.lang.String headline) {
        this.headline = headline;
    }


    /**
     * Gets the description value for this AlertInfo.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this AlertInfo.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the instruction value for this AlertInfo.
     * 
     * @return instruction
     */
    public java.lang.String getInstruction() {
        return instruction;
    }


    /**
     * Sets the instruction value for this AlertInfo.
     * 
     * @param instruction
     */
    public void setInstruction(java.lang.String instruction) {
        this.instruction = instruction;
    }


    /**
     * Gets the web value for this AlertInfo.
     * 
     * @return web
     */
    public org.apache.axis.types.URI getWeb() {
        return web;
    }


    /**
     * Sets the web value for this AlertInfo.
     * 
     * @param web
     */
    public void setWeb(org.apache.axis.types.URI web) {
        this.web = web;
    }


    /**
     * Gets the contact value for this AlertInfo.
     * 
     * @return contact
     */
    public java.lang.String getContact() {
        return contact;
    }


    /**
     * Sets the contact value for this AlertInfo.
     * 
     * @param contact
     */
    public void setContact(java.lang.String contact) {
        this.contact = contact;
    }


    /**
     * Gets the parameter value for this AlertInfo.
     * 
     * @return parameter
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoParameter[] getParameter() {
        return parameter;
    }


    /**
     * Sets the parameter value for this AlertInfo.
     * 
     * @param parameter
     */
    public void setParameter(_2._1.cap.emergency.tc.names.oasis.AlertInfoParameter[] parameter) {
        this.parameter = parameter;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfoParameter getParameter(int i) {
        return this.parameter[i];
    }

    public void setParameter(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfoParameter _value) {
        this.parameter[i] = _value;
    }


    /**
     * Gets the resource value for this AlertInfo.
     * 
     * @return resource
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoResource[] getResource() {
        return resource;
    }


    /**
     * Sets the resource value for this AlertInfo.
     * 
     * @param resource
     */
    public void setResource(_2._1.cap.emergency.tc.names.oasis.AlertInfoResource[] resource) {
        this.resource = resource;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfoResource getResource(int i) {
        return this.resource[i];
    }

    public void setResource(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfoResource _value) {
        this.resource[i] = _value;
    }


    /**
     * Gets the area value for this AlertInfo.
     * 
     * @return area
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoArea[] getArea() {
        return area;
    }


    /**
     * Sets the area value for this AlertInfo.
     * 
     * @param area
     */
    public void setArea(_2._1.cap.emergency.tc.names.oasis.AlertInfoArea[] area) {
        this.area = area;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfoArea getArea(int i) {
        return this.area[i];
    }

    public void setArea(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfoArea _value) {
        this.area[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlertInfo)) return false;
        AlertInfo other = (AlertInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.category==null && other.getCategory()==null) || 
             (this.category!=null &&
              java.util.Arrays.equals(this.category, other.getCategory()))) &&
            ((this.event==null && other.getEvent()==null) || 
             (this.event!=null &&
              this.event.equals(other.getEvent()))) &&
            ((this.responseType==null && other.getResponseType()==null) || 
             (this.responseType!=null &&
              java.util.Arrays.equals(this.responseType, other.getResponseType()))) &&
            ((this.urgency==null && other.getUrgency()==null) || 
             (this.urgency!=null &&
              this.urgency.equals(other.getUrgency()))) &&
            ((this.severity==null && other.getSeverity()==null) || 
             (this.severity!=null &&
              this.severity.equals(other.getSeverity()))) &&
            ((this.certainty==null && other.getCertainty()==null) || 
             (this.certainty!=null &&
              this.certainty.equals(other.getCertainty()))) &&
            ((this.audience==null && other.getAudience()==null) || 
             (this.audience!=null &&
              this.audience.equals(other.getAudience()))) &&
            ((this.eventCode==null && other.getEventCode()==null) || 
             (this.eventCode!=null &&
              java.util.Arrays.equals(this.eventCode, other.getEventCode()))) &&
            ((this.effective==null && other.getEffective()==null) || 
             (this.effective!=null &&
              this.effective.equals(other.getEffective()))) &&
            ((this.onset==null && other.getOnset()==null) || 
             (this.onset!=null &&
              this.onset.equals(other.getOnset()))) &&
            ((this.expires==null && other.getExpires()==null) || 
             (this.expires!=null &&
              this.expires.equals(other.getExpires()))) &&
            ((this.senderName==null && other.getSenderName()==null) || 
             (this.senderName!=null &&
              this.senderName.equals(other.getSenderName()))) &&
            ((this.headline==null && other.getHeadline()==null) || 
             (this.headline!=null &&
              this.headline.equals(other.getHeadline()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.instruction==null && other.getInstruction()==null) || 
             (this.instruction!=null &&
              this.instruction.equals(other.getInstruction()))) &&
            ((this.web==null && other.getWeb()==null) || 
             (this.web!=null &&
              this.web.equals(other.getWeb()))) &&
            ((this.contact==null && other.getContact()==null) || 
             (this.contact!=null &&
              this.contact.equals(other.getContact()))) &&
            ((this.parameter==null && other.getParameter()==null) || 
             (this.parameter!=null &&
              java.util.Arrays.equals(this.parameter, other.getParameter()))) &&
            ((this.resource==null && other.getResource()==null) || 
             (this.resource!=null &&
              java.util.Arrays.equals(this.resource, other.getResource()))) &&
            ((this.area==null && other.getArea()==null) || 
             (this.area!=null &&
              java.util.Arrays.equals(this.area, other.getArea())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getCategory() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCategory());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCategory(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEvent() != null) {
            _hashCode += getEvent().hashCode();
        }
        if (getResponseType() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getResponseType());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getResponseType(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getUrgency() != null) {
            _hashCode += getUrgency().hashCode();
        }
        if (getSeverity() != null) {
            _hashCode += getSeverity().hashCode();
        }
        if (getCertainty() != null) {
            _hashCode += getCertainty().hashCode();
        }
        if (getAudience() != null) {
            _hashCode += getAudience().hashCode();
        }
        if (getEventCode() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEventCode());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEventCode(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEffective() != null) {
            _hashCode += getEffective().hashCode();
        }
        if (getOnset() != null) {
            _hashCode += getOnset().hashCode();
        }
        if (getExpires() != null) {
            _hashCode += getExpires().hashCode();
        }
        if (getSenderName() != null) {
            _hashCode += getSenderName().hashCode();
        }
        if (getHeadline() != null) {
            _hashCode += getHeadline().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getInstruction() != null) {
            _hashCode += getInstruction().hashCode();
        }
        if (getWeb() != null) {
            _hashCode += getWeb().hashCode();
        }
        if (getContact() != null) {
            _hashCode += getContact().hashCode();
        }
        if (getParameter() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParameter());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParameter(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getResource() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getResource());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getResource(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getArea() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArea());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArea(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlertInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "language"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("category");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "category"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>category"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("event");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "event"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "responseType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>responseType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("urgency");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "urgency"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>urgency"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("severity");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "severity"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>severity"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certainty");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "certainty"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>certainty"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("audience");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "audience"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("eventCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "eventCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>eventCode"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effective");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "effective"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("onset");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "onset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expires");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "expires"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("senderName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "senderName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("headline");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "headline"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("instruction");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "instruction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("web");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "web"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyURI"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contact");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "contact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parameter");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "parameter"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>parameter"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resource");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "resource"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>resource"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("area");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "area"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>area"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
