/**
 * AlertInfoUrgency.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package _2._1.cap.emergency.tc.names.oasis;

public class AlertInfoUrgency implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected AlertInfoUrgency(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _Immediate = "Immediate";
    public static final java.lang.String _Expected = "Expected";
    public static final java.lang.String _Future = "Future";
    public static final java.lang.String _Past = "Past";
    public static final java.lang.String _Unknown = "Unknown";
    public static final AlertInfoUrgency Immediate = new AlertInfoUrgency(_Immediate);
    public static final AlertInfoUrgency Expected = new AlertInfoUrgency(_Expected);
    public static final AlertInfoUrgency Future = new AlertInfoUrgency(_Future);
    public static final AlertInfoUrgency Past = new AlertInfoUrgency(_Past);
    public static final AlertInfoUrgency Unknown = new AlertInfoUrgency(_Unknown);
    public java.lang.String getValue() { return _value_;}
    public static AlertInfoUrgency fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        AlertInfoUrgency enumeration = (AlertInfoUrgency)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static AlertInfoUrgency fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlertInfoUrgency.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>urgency"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
