/**
 * Alert.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package _2._1.cap.emergency.tc.names.oasis;

public class Alert  implements java.io.Serializable, org.apache.axis.encoding.AnyContentType {
    private java.lang.String identifier;

    private java.lang.String sender;

    private java.util.Calendar sent;

    private _2._1.cap.emergency.tc.names.oasis.AlertStatus status;

    private _2._1.cap.emergency.tc.names.oasis.AlertMsgType msgType;

    private java.lang.String source;

    private _2._1.cap.emergency.tc.names.oasis.AlertScope scope;

    private java.lang.String restriction;

    private java.lang.String addresses;

    private java.lang.String[] code;

    private java.lang.String note;

    private java.lang.String references;

    private java.lang.String incidents;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfo[] info;

    private org.apache.axis.message.MessageElement [] _any;

    public Alert() {
    }

    public Alert(
           java.lang.String identifier,
           java.lang.String sender,
           java.util.Calendar sent,
           _2._1.cap.emergency.tc.names.oasis.AlertStatus status,
           _2._1.cap.emergency.tc.names.oasis.AlertMsgType msgType,
           java.lang.String source,
           _2._1.cap.emergency.tc.names.oasis.AlertScope scope,
           java.lang.String restriction,
           java.lang.String addresses,
           java.lang.String[] code,
           java.lang.String note,
           java.lang.String references,
           java.lang.String incidents,
           _2._1.cap.emergency.tc.names.oasis.AlertInfo[] info,
           org.apache.axis.message.MessageElement [] _any) {
           this.identifier = identifier;
           this.sender = sender;
           this.sent = sent;
           this.status = status;
           this.msgType = msgType;
           this.source = source;
           this.scope = scope;
           this.restriction = restriction;
           this.addresses = addresses;
           this.code = code;
           this.note = note;
           this.references = references;
           this.incidents = incidents;
           this.info = info;
           this._any = _any;
    }


    /**
     * Gets the identifier value for this Alert.
     * 
     * @return identifier
     */
    public java.lang.String getIdentifier() {
        return identifier;
    }


    /**
     * Sets the identifier value for this Alert.
     * 
     * @param identifier
     */
    public void setIdentifier(java.lang.String identifier) {
        this.identifier = identifier;
    }


    /**
     * Gets the sender value for this Alert.
     * 
     * @return sender
     */
    public java.lang.String getSender() {
        return sender;
    }


    /**
     * Sets the sender value for this Alert.
     * 
     * @param sender
     */
    public void setSender(java.lang.String sender) {
        this.sender = sender;
    }


    /**
     * Gets the sent value for this Alert.
     * 
     * @return sent
     */
    public java.util.Calendar getSent() {
        return sent;
    }


    /**
     * Sets the sent value for this Alert.
     * 
     * @param sent
     */
    public void setSent(java.util.Calendar sent) {
        this.sent = sent;
    }


    /**
     * Gets the status value for this Alert.
     * 
     * @return status
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertStatus getStatus() {
        return status;
    }


    /**
     * Sets the status value for this Alert.
     * 
     * @param status
     */
    public void setStatus(_2._1.cap.emergency.tc.names.oasis.AlertStatus status) {
        this.status = status;
    }


    /**
     * Gets the msgType value for this Alert.
     * 
     * @return msgType
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertMsgType getMsgType() {
        return msgType;
    }


    /**
     * Sets the msgType value for this Alert.
     * 
     * @param msgType
     */
    public void setMsgType(_2._1.cap.emergency.tc.names.oasis.AlertMsgType msgType) {
        this.msgType = msgType;
    }


    /**
     * Gets the source value for this Alert.
     * 
     * @return source
     */
    public java.lang.String getSource() {
        return source;
    }


    /**
     * Sets the source value for this Alert.
     * 
     * @param source
     */
    public void setSource(java.lang.String source) {
        this.source = source;
    }


    /**
     * Gets the scope value for this Alert.
     * 
     * @return scope
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertScope getScope() {
        return scope;
    }


    /**
     * Sets the scope value for this Alert.
     * 
     * @param scope
     */
    public void setScope(_2._1.cap.emergency.tc.names.oasis.AlertScope scope) {
        this.scope = scope;
    }


    /**
     * Gets the restriction value for this Alert.
     * 
     * @return restriction
     */
    public java.lang.String getRestriction() {
        return restriction;
    }


    /**
     * Sets the restriction value for this Alert.
     * 
     * @param restriction
     */
    public void setRestriction(java.lang.String restriction) {
        this.restriction = restriction;
    }


    /**
     * Gets the addresses value for this Alert.
     * 
     * @return addresses
     */
    public java.lang.String getAddresses() {
        return addresses;
    }


    /**
     * Sets the addresses value for this Alert.
     * 
     * @param addresses
     */
    public void setAddresses(java.lang.String addresses) {
        this.addresses = addresses;
    }


    /**
     * Gets the code value for this Alert.
     * 
     * @return code
     */
    public java.lang.String[] getCode() {
        return code;
    }


    /**
     * Sets the code value for this Alert.
     * 
     * @param code
     */
    public void setCode(java.lang.String[] code) {
        this.code = code;
    }

    public java.lang.String getCode(int i) {
        return this.code[i];
    }

    public void setCode(int i, java.lang.String _value) {
        this.code[i] = _value;
    }


    /**
     * Gets the note value for this Alert.
     * 
     * @return note
     */
    public java.lang.String getNote() {
        return note;
    }


    /**
     * Sets the note value for this Alert.
     * 
     * @param note
     */
    public void setNote(java.lang.String note) {
        this.note = note;
    }


    /**
     * Gets the references value for this Alert.
     * 
     * @return references
     */
    public java.lang.String getReferences() {
        return references;
    }


    /**
     * Sets the references value for this Alert.
     * 
     * @param references
     */
    public void setReferences(java.lang.String references) {
        this.references = references;
    }


    /**
     * Gets the incidents value for this Alert.
     * 
     * @return incidents
     */
    public java.lang.String getIncidents() {
        return incidents;
    }


    /**
     * Sets the incidents value for this Alert.
     * 
     * @param incidents
     */
    public void setIncidents(java.lang.String incidents) {
        this.incidents = incidents;
    }


    /**
     * Gets the info value for this Alert.
     * 
     * @return info
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfo[] getInfo() {
        return info;
    }


    /**
     * Sets the info value for this Alert.
     * 
     * @param info
     */
    public void setInfo(_2._1.cap.emergency.tc.names.oasis.AlertInfo[] info) {
        this.info = info;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfo getInfo(int i) {
        return this.info[i];
    }

    public void setInfo(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfo _value) {
        this.info[i] = _value;
    }


    /**
     * Gets the _any value for this Alert.
     * 
     * @return _any
     */
    public org.apache.axis.message.MessageElement [] get_any() {
        return _any;
    }


    /**
     * Sets the _any value for this Alert.
     * 
     * @param _any
     */
    public void set_any(org.apache.axis.message.MessageElement [] _any) {
        this._any = _any;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Alert)) return false;
        Alert other = (Alert) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.identifier==null && other.getIdentifier()==null) || 
             (this.identifier!=null &&
              this.identifier.equals(other.getIdentifier()))) &&
            ((this.sender==null && other.getSender()==null) || 
             (this.sender!=null &&
              this.sender.equals(other.getSender()))) &&
            ((this.sent==null && other.getSent()==null) || 
             (this.sent!=null &&
              this.sent.equals(other.getSent()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.msgType==null && other.getMsgType()==null) || 
             (this.msgType!=null &&
              this.msgType.equals(other.getMsgType()))) &&
            ((this.source==null && other.getSource()==null) || 
             (this.source!=null &&
              this.source.equals(other.getSource()))) &&
            ((this.scope==null && other.getScope()==null) || 
             (this.scope!=null &&
              this.scope.equals(other.getScope()))) &&
            ((this.restriction==null && other.getRestriction()==null) || 
             (this.restriction!=null &&
              this.restriction.equals(other.getRestriction()))) &&
            ((this.addresses==null && other.getAddresses()==null) || 
             (this.addresses!=null &&
              this.addresses.equals(other.getAddresses()))) &&
            ((this.code==null && other.getCode()==null) || 
             (this.code!=null &&
              java.util.Arrays.equals(this.code, other.getCode()))) &&
            ((this.note==null && other.getNote()==null) || 
             (this.note!=null &&
              this.note.equals(other.getNote()))) &&
            ((this.references==null && other.getReferences()==null) || 
             (this.references!=null &&
              this.references.equals(other.getReferences()))) &&
            ((this.incidents==null && other.getIncidents()==null) || 
             (this.incidents!=null &&
              this.incidents.equals(other.getIncidents()))) &&
            ((this.info==null && other.getInfo()==null) || 
             (this.info!=null &&
              java.util.Arrays.equals(this.info, other.getInfo()))) &&
            ((this._any==null && other.get_any()==null) || 
             (this._any!=null &&
              java.util.Arrays.equals(this._any, other.get_any())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdentifier() != null) {
            _hashCode += getIdentifier().hashCode();
        }
        if (getSender() != null) {
            _hashCode += getSender().hashCode();
        }
        if (getSent() != null) {
            _hashCode += getSent().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getMsgType() != null) {
            _hashCode += getMsgType().hashCode();
        }
        if (getSource() != null) {
            _hashCode += getSource().hashCode();
        }
        if (getScope() != null) {
            _hashCode += getScope().hashCode();
        }
        if (getRestriction() != null) {
            _hashCode += getRestriction().hashCode();
        }
        if (getAddresses() != null) {
            _hashCode += getAddresses().hashCode();
        }
        if (getCode() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCode());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCode(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNote() != null) {
            _hashCode += getNote().hashCode();
        }
        if (getReferences() != null) {
            _hashCode += getReferences().hashCode();
        }
        if (getIncidents() != null) {
            _hashCode += getIncidents().hashCode();
        }
        if (getInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (get_any() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(get_any());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(get_any(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Alert.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">alert"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identifier");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "identifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sender");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "sender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sent");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "sent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>status"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "msgType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>msgType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("source");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "source"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("scope");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "scope"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>scope"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restriction");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "restriction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addresses");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "addresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("code");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "code"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("note");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "note"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("references");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "references"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("incidents");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "incidents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("info");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "info"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
