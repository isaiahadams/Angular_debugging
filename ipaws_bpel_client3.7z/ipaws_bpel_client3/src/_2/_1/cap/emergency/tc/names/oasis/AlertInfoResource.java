/**
 * AlertInfoResource.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package _2._1.cap.emergency.tc.names.oasis;

public class AlertInfoResource  implements java.io.Serializable {
    private java.lang.String resourceDesc;

    private java.lang.String mimeType;

    private java.math.BigInteger size;

    private org.apache.axis.types.URI uri;

    private java.lang.String derefUri;

    private java.lang.String digest;

    public AlertInfoResource() {
    }

    public AlertInfoResource(
           java.lang.String resourceDesc,
           java.lang.String mimeType,
           java.math.BigInteger size,
           org.apache.axis.types.URI uri,
           java.lang.String derefUri,
           java.lang.String digest) {
           this.resourceDesc = resourceDesc;
           this.mimeType = mimeType;
           this.size = size;
           this.uri = uri;
           this.derefUri = derefUri;
           this.digest = digest;
    }


    /**
     * Gets the resourceDesc value for this AlertInfoResource.
     * 
     * @return resourceDesc
     */
    public java.lang.String getResourceDesc() {
        return resourceDesc;
    }


    /**
     * Sets the resourceDesc value for this AlertInfoResource.
     * 
     * @param resourceDesc
     */
    public void setResourceDesc(java.lang.String resourceDesc) {
        this.resourceDesc = resourceDesc;
    }


    /**
     * Gets the mimeType value for this AlertInfoResource.
     * 
     * @return mimeType
     */
    public java.lang.String getMimeType() {
        return mimeType;
    }


    /**
     * Sets the mimeType value for this AlertInfoResource.
     * 
     * @param mimeType
     */
    public void setMimeType(java.lang.String mimeType) {
        this.mimeType = mimeType;
    }


    /**
     * Gets the size value for this AlertInfoResource.
     * 
     * @return size
     */
    public java.math.BigInteger getSize() {
        return size;
    }


    /**
     * Sets the size value for this AlertInfoResource.
     * 
     * @param size
     */
    public void setSize(java.math.BigInteger size) {
        this.size = size;
    }


    /**
     * Gets the uri value for this AlertInfoResource.
     * 
     * @return uri
     */
    public org.apache.axis.types.URI getUri() {
        return uri;
    }


    /**
     * Sets the uri value for this AlertInfoResource.
     * 
     * @param uri
     */
    public void setUri(org.apache.axis.types.URI uri) {
        this.uri = uri;
    }


    /**
     * Gets the derefUri value for this AlertInfoResource.
     * 
     * @return derefUri
     */
    public java.lang.String getDerefUri() {
        return derefUri;
    }


    /**
     * Sets the derefUri value for this AlertInfoResource.
     * 
     * @param derefUri
     */
    public void setDerefUri(java.lang.String derefUri) {
        this.derefUri = derefUri;
    }


    /**
     * Gets the digest value for this AlertInfoResource.
     * 
     * @return digest
     */
    public java.lang.String getDigest() {
        return digest;
    }


    /**
     * Sets the digest value for this AlertInfoResource.
     * 
     * @param digest
     */
    public void setDigest(java.lang.String digest) {
        this.digest = digest;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlertInfoResource)) return false;
        AlertInfoResource other = (AlertInfoResource) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.resourceDesc==null && other.getResourceDesc()==null) || 
             (this.resourceDesc!=null &&
              this.resourceDesc.equals(other.getResourceDesc()))) &&
            ((this.mimeType==null && other.getMimeType()==null) || 
             (this.mimeType!=null &&
              this.mimeType.equals(other.getMimeType()))) &&
            ((this.size==null && other.getSize()==null) || 
             (this.size!=null &&
              this.size.equals(other.getSize()))) &&
            ((this.uri==null && other.getUri()==null) || 
             (this.uri!=null &&
              this.uri.equals(other.getUri()))) &&
            ((this.derefUri==null && other.getDerefUri()==null) || 
             (this.derefUri!=null &&
              this.derefUri.equals(other.getDerefUri()))) &&
            ((this.digest==null && other.getDigest()==null) || 
             (this.digest!=null &&
              this.digest.equals(other.getDigest())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getResourceDesc() != null) {
            _hashCode += getResourceDesc().hashCode();
        }
        if (getMimeType() != null) {
            _hashCode += getMimeType().hashCode();
        }
        if (getSize() != null) {
            _hashCode += getSize().hashCode();
        }
        if (getUri() != null) {
            _hashCode += getUri().hashCode();
        }
        if (getDerefUri() != null) {
            _hashCode += getDerefUri().hashCode();
        }
        if (getDigest() != null) {
            _hashCode += getDigest().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlertInfoResource.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>resource"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resourceDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "resourceDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mimeType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "mimeType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("size");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "size"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uri");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "uri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyURI"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("derefUri");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "derefUri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digest");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "digest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
