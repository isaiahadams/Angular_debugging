/**
 * AlertInfoArea.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package _2._1.cap.emergency.tc.names.oasis;

public class AlertInfoArea  implements java.io.Serializable {
    private java.lang.String areaDesc;

    private java.lang.String[] polygon;

    private java.lang.String[] circle;

    private _2._1.cap.emergency.tc.names.oasis.AlertInfoAreaGeocode[] geocode;

    private java.math.BigDecimal altitude;

    private java.math.BigDecimal ceiling;

    public AlertInfoArea() {
    }

    public AlertInfoArea(
           java.lang.String areaDesc,
           java.lang.String[] polygon,
           java.lang.String[] circle,
           _2._1.cap.emergency.tc.names.oasis.AlertInfoAreaGeocode[] geocode,
           java.math.BigDecimal altitude,
           java.math.BigDecimal ceiling) {
           this.areaDesc = areaDesc;
           this.polygon = polygon;
           this.circle = circle;
           this.geocode = geocode;
           this.altitude = altitude;
           this.ceiling = ceiling;
    }


    /**
     * Gets the areaDesc value for this AlertInfoArea.
     * 
     * @return areaDesc
     */
    public java.lang.String getAreaDesc() {
        return areaDesc;
    }


    /**
     * Sets the areaDesc value for this AlertInfoArea.
     * 
     * @param areaDesc
     */
    public void setAreaDesc(java.lang.String areaDesc) {
        this.areaDesc = areaDesc;
    }


    /**
     * Gets the polygon value for this AlertInfoArea.
     * 
     * @return polygon
     */
    public java.lang.String[] getPolygon() {
        return polygon;
    }


    /**
     * Sets the polygon value for this AlertInfoArea.
     * 
     * @param polygon
     */
    public void setPolygon(java.lang.String[] polygon) {
        this.polygon = polygon;
    }

    public java.lang.String getPolygon(int i) {
        return this.polygon[i];
    }

    public void setPolygon(int i, java.lang.String _value) {
        this.polygon[i] = _value;
    }


    /**
     * Gets the circle value for this AlertInfoArea.
     * 
     * @return circle
     */
    public java.lang.String[] getCircle() {
        return circle;
    }


    /**
     * Sets the circle value for this AlertInfoArea.
     * 
     * @param circle
     */
    public void setCircle(java.lang.String[] circle) {
        this.circle = circle;
    }

    public java.lang.String getCircle(int i) {
        return this.circle[i];
    }

    public void setCircle(int i, java.lang.String _value) {
        this.circle[i] = _value;
    }


    /**
     * Gets the geocode value for this AlertInfoArea.
     * 
     * @return geocode
     */
    public _2._1.cap.emergency.tc.names.oasis.AlertInfoAreaGeocode[] getGeocode() {
        return geocode;
    }


    /**
     * Sets the geocode value for this AlertInfoArea.
     * 
     * @param geocode
     */
    public void setGeocode(_2._1.cap.emergency.tc.names.oasis.AlertInfoAreaGeocode[] geocode) {
        this.geocode = geocode;
    }

    public _2._1.cap.emergency.tc.names.oasis.AlertInfoAreaGeocode getGeocode(int i) {
        return this.geocode[i];
    }

    public void setGeocode(int i, _2._1.cap.emergency.tc.names.oasis.AlertInfoAreaGeocode _value) {
        this.geocode[i] = _value;
    }


    /**
     * Gets the altitude value for this AlertInfoArea.
     * 
     * @return altitude
     */
    public java.math.BigDecimal getAltitude() {
        return altitude;
    }


    /**
     * Sets the altitude value for this AlertInfoArea.
     * 
     * @param altitude
     */
    public void setAltitude(java.math.BigDecimal altitude) {
        this.altitude = altitude;
    }


    /**
     * Gets the ceiling value for this AlertInfoArea.
     * 
     * @return ceiling
     */
    public java.math.BigDecimal getCeiling() {
        return ceiling;
    }


    /**
     * Sets the ceiling value for this AlertInfoArea.
     * 
     * @param ceiling
     */
    public void setCeiling(java.math.BigDecimal ceiling) {
        this.ceiling = ceiling;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlertInfoArea)) return false;
        AlertInfoArea other = (AlertInfoArea) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.areaDesc==null && other.getAreaDesc()==null) || 
             (this.areaDesc!=null &&
              this.areaDesc.equals(other.getAreaDesc()))) &&
            ((this.polygon==null && other.getPolygon()==null) || 
             (this.polygon!=null &&
              java.util.Arrays.equals(this.polygon, other.getPolygon()))) &&
            ((this.circle==null && other.getCircle()==null) || 
             (this.circle!=null &&
              java.util.Arrays.equals(this.circle, other.getCircle()))) &&
            ((this.geocode==null && other.getGeocode()==null) || 
             (this.geocode!=null &&
              java.util.Arrays.equals(this.geocode, other.getGeocode()))) &&
            ((this.altitude==null && other.getAltitude()==null) || 
             (this.altitude!=null &&
              this.altitude.equals(other.getAltitude()))) &&
            ((this.ceiling==null && other.getCeiling()==null) || 
             (this.ceiling!=null &&
              this.ceiling.equals(other.getCeiling())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAreaDesc() != null) {
            _hashCode += getAreaDesc().hashCode();
        }
        if (getPolygon() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPolygon());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPolygon(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCircle() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCircle());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCircle(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGeocode() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGeocode());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGeocode(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAltitude() != null) {
            _hashCode += getAltitude().hashCode();
        }
        if (getCeiling() != null) {
            _hashCode += getCeiling().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlertInfoArea.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>area"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("areaDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "areaDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("polygon");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "polygon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("circle");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "circle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geocode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "geocode"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>>alert>info>area>geocode"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("altitude");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "altitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ceiling");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "ceiling"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
