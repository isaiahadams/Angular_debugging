/**
 * ProcessResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess;

public class ProcessResponse  implements java.io.Serializable {
    private java.lang.String cmacReturn;

    private java.lang.String nwemReturn;

    private java.lang.String easReturn;

    private java.lang.String publicReturn;

    public ProcessResponse() {
    }

    public ProcessResponse(
           java.lang.String cmacReturn,
           java.lang.String nwemReturn,
           java.lang.String easReturn,
           java.lang.String publicReturn) {
           this.cmacReturn = cmacReturn;
           this.nwemReturn = nwemReturn;
           this.easReturn = easReturn;
           this.publicReturn = publicReturn;
    }


    /**
     * Gets the cmacReturn value for this ProcessResponse.
     * 
     * @return cmacReturn
     */
    public java.lang.String getCmacReturn() {
        return cmacReturn;
    }


    /**
     * Sets the cmacReturn value for this ProcessResponse.
     * 
     * @param cmacReturn
     */
    public void setCmacReturn(java.lang.String cmacReturn) {
        this.cmacReturn = cmacReturn;
    }


    /**
     * Gets the nwemReturn value for this ProcessResponse.
     * 
     * @return nwemReturn
     */
    public java.lang.String getNwemReturn() {
        return nwemReturn;
    }


    /**
     * Sets the nwemReturn value for this ProcessResponse.
     * 
     * @param nwemReturn
     */
    public void setNwemReturn(java.lang.String nwemReturn) {
        this.nwemReturn = nwemReturn;
    }


    /**
     * Gets the easReturn value for this ProcessResponse.
     * 
     * @return easReturn
     */
    public java.lang.String getEasReturn() {
        return easReturn;
    }


    /**
     * Sets the easReturn value for this ProcessResponse.
     * 
     * @param easReturn
     */
    public void setEasReturn(java.lang.String easReturn) {
        this.easReturn = easReturn;
    }


    /**
     * Gets the publicReturn value for this ProcessResponse.
     * 
     * @return publicReturn
     */
    public java.lang.String getPublicReturn() {
        return publicReturn;
    }


    /**
     * Sets the publicReturn value for this ProcessResponse.
     * 
     * @param publicReturn
     */
    public void setPublicReturn(java.lang.String publicReturn) {
        this.publicReturn = publicReturn;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProcessResponse)) return false;
        ProcessResponse other = (ProcessResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cmacReturn==null && other.getCmacReturn()==null) || 
             (this.cmacReturn!=null &&
              this.cmacReturn.equals(other.getCmacReturn()))) &&
            ((this.nwemReturn==null && other.getNwemReturn()==null) || 
             (this.nwemReturn!=null &&
              this.nwemReturn.equals(other.getNwemReturn()))) &&
            ((this.easReturn==null && other.getEasReturn()==null) || 
             (this.easReturn!=null &&
              this.easReturn.equals(other.getEasReturn()))) &&
            ((this.publicReturn==null && other.getPublicReturn()==null) || 
             (this.publicReturn!=null &&
              this.publicReturn.equals(other.getPublicReturn())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCmacReturn() != null) {
            _hashCode += getCmacReturn().hashCode();
        }
        if (getNwemReturn() != null) {
            _hashCode += getNwemReturn().hashCode();
        }
        if (getEasReturn() != null) {
            _hashCode += getEasReturn().hashCode();
        }
        if (getPublicReturn() != null) {
            _hashCode += getPublicReturn().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProcessResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", ">processResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cmacReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "cmacReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nwemReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "nwemReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("easReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "easReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publicReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "publicReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
