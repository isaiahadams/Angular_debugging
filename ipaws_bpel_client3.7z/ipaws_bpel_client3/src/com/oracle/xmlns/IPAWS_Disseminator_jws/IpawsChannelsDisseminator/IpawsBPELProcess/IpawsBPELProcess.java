/**
 * IpawsBPELProcess.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess;

public interface IpawsBPELProcess extends java.rmi.Remote {
    public void process(_2._1.cap.emergency.tc.names.oasis.Alert capAlertForCmac, _2._1.cap.emergency.tc.names.oasis.Alert capAlert, java.lang.String CMAC_message_number, java.lang.String msgType, java.lang.String CMAC_referenced_message_number, java.lang.String CMAC_cap_alert_uri, java.lang.Boolean isNWEM, java.lang.Boolean isCMAC, java.lang.Boolean isCMACv2, java.lang.Boolean isEAS, java.lang.Boolean isPUBLIC, java.lang.String cogId, java.lang.String userName, javax.xml.rpc.holders.StringHolder cmacReturn, javax.xml.rpc.holders.StringHolder nwemReturn, javax.xml.rpc.holders.StringHolder easReturn, javax.xml.rpc.holders.StringHolder publicReturn) throws java.rmi.RemoteException;
}
