/**
 * IpawsBPELProcessBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess;

public class IpawsBPELProcessBindingStub extends org.apache.axis.client.Stub implements com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcess {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[1];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("process");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "capAlertForCmac"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "alert"), _2._1.cap.emergency.tc.names.oasis.Alert.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "capAlert"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "alert"), _2._1.cap.emergency.tc.names.oasis.Alert.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "CMAC_message_number"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "msgType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "CMAC_referenced_message_number"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "CMAC_cap_alert_uri"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isNWEM"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isCMAC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isCMACv2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isEAS"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isPUBLIC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "cogId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "userName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "cmacReturn"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "nwemReturn"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "easReturn"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "publicReturn"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

    }

    public IpawsBPELProcessBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public IpawsBPELProcessBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public IpawsBPELProcessBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", ">>inputParams>CMAC_message_number");
            cachedSerQNames.add(qName);
            cls = byte[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(arraysf);
            cachedDeserFactories.add(arraydf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", ">>inputParams>CMAC_referenced_message_number");
            cachedSerQNames.add(qName);
            cls = byte[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(arraysf);
            cachedDeserFactories.add(arraydf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", ">CMAC2TransformServiceException");
            cachedSerQNames.add(qName);
            cls = services.ipaws.fema.gov.CMAC2TransformService.CMAC2TransformServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", ">inputParams");
            cachedSerQNames.add(qName);
            cls = services.ipaws.fema.gov.CMAC2TransformService.InputParams.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMACTransformService/", ">>inputParams>CMAC_message_number");
            cachedSerQNames.add(qName);
            cls = byte[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(arraysf);
            cachedDeserFactories.add(arraydf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMACTransformService/", ">>inputParams>CMAC_referenced_message_number");
            cachedSerQNames.add(qName);
            cls = byte[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(arraysf);
            cachedDeserFactories.add(arraydf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMACTransformService/", ">CMACTransformServiceException");
            cachedSerQNames.add(qName);
            cls = services.ipaws.fema.gov.CMACTransformService.CMACTransformServiceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMACTransformService/", ">inputParams");
            cachedSerQNames.add(qName);
            cls = services.ipaws.fema.gov.CMACTransformService.InputParams.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/HazCollectInterface/", ">hazCollectInput");
            cachedSerQNames.add(qName);
            cls = services.ipaws.fema.gov.HazCollectInterface.HazCollectInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://gov.fema.ipaws.services/HazCollectInterface/", ">HazCollectInterfaceException");
            cachedSerQNames.add(qName);
            cls = services.ipaws.fema.gov.HazCollectInterface.HazCollectInterfaceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", ">process");
            cachedSerQNames.add(qName);
            cls = com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.Process.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", ">processResponse");
            cachedSerQNames.add(qName);
            cls = com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.ProcessResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>>alert>info>area>geocode");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoAreaGeocode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>area");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoArea.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>category");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoCategory.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>certainty");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoCertainty.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>effective");
            cachedSerQNames.add(qName);
            cls = java.util.Calendar.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>eventCode");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoEventCode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>expires");
            cachedSerQNames.add(qName);
            cls = java.util.Calendar.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>onset");
            cachedSerQNames.add(qName);
            cls = java.util.Calendar.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>parameter");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoParameter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>resource");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoResource.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>responseType");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>severity");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoSeverity.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">>alert>info>urgency");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfoUrgency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">alert>info");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">alert>msgType");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertMsgType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">alert>scope");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertScope.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">alert>sent");
            cachedSerQNames.add(qName);
            cls = java.util.Calendar.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", ">alert>status");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.AlertStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "alert");
            cachedSerQNames.add(qName);
            cls = _2._1.cap.emergency.tc.names.oasis.Alert.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public void process(_2._1.cap.emergency.tc.names.oasis.Alert capAlertForCmac, _2._1.cap.emergency.tc.names.oasis.Alert capAlert, java.lang.String CMAC_message_number, java.lang.String msgType, java.lang.String CMAC_referenced_message_number, java.lang.String CMAC_cap_alert_uri, java.lang.Boolean isNWEM, java.lang.Boolean isCMAC, java.lang.Boolean isCMACv2, java.lang.Boolean isEAS, java.lang.Boolean isPUBLIC, java.lang.String cogId, java.lang.String userName, javax.xml.rpc.holders.StringHolder cmacReturn, javax.xml.rpc.holders.StringHolder nwemReturn, javax.xml.rpc.holders.StringHolder easReturn, javax.xml.rpc.holders.StringHolder publicReturn) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("process");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "process"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {capAlertForCmac, capAlert, CMAC_message_number, msgType, CMAC_referenced_message_number, CMAC_cap_alert_uri, isNWEM, isCMAC, isCMACv2, isEAS, isPUBLIC, cogId, userName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                cmacReturn.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "cmacReturn"));
            } catch (java.lang.Exception _exception) {
                cmacReturn.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "cmacReturn")), java.lang.String.class);
            }
            try {
                nwemReturn.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "nwemReturn"));
            } catch (java.lang.Exception _exception) {
                nwemReturn.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "nwemReturn")), java.lang.String.class);
            }
            try {
                easReturn.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "easReturn"));
            } catch (java.lang.Exception _exception) {
                easReturn.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "easReturn")), java.lang.String.class);
            }
            try {
                publicReturn.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "publicReturn"));
            } catch (java.lang.Exception _exception) {
                publicReturn.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "publicReturn")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
