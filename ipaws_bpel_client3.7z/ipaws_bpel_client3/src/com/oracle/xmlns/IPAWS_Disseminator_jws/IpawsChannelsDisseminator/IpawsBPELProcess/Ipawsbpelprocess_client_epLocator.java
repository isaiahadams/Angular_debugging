/**
 * Ipawsbpelprocess_client_epLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess;

public class Ipawsbpelprocess_client_epLocator extends org.apache.axis.client.Service implements com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.Ipawsbpelprocess_client_ep {

    public Ipawsbpelprocess_client_epLocator() {
    }


    public Ipawsbpelprocess_client_epLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Ipawsbpelprocess_client_epLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for IpawsBPELProcess_pt
    private java.lang.String IpawsBPELProcess_pt_address = "http://ccdex09vm07.femaeadis.com:8001/soa-infra/services/default/IpawsChannelsDisseminator/ipawsbpelprocess_client_ep";

    public java.lang.String getIpawsBPELProcess_ptAddress() {
        return IpawsBPELProcess_pt_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String IpawsBPELProcess_ptWSDDServiceName = "IpawsBPELProcess_pt";

    public java.lang.String getIpawsBPELProcess_ptWSDDServiceName() {
        return IpawsBPELProcess_ptWSDDServiceName;
    }

    public void setIpawsBPELProcess_ptWSDDServiceName(java.lang.String name) {
        IpawsBPELProcess_ptWSDDServiceName = name;
    }

    public com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcess getIpawsBPELProcess_pt() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(IpawsBPELProcess_pt_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getIpawsBPELProcess_pt(endpoint);
    }

    public com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcess getIpawsBPELProcess_pt(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcessBindingStub _stub = new com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcessBindingStub(portAddress, this);
            _stub.setPortName(getIpawsBPELProcess_ptWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setIpawsBPELProcess_ptEndpointAddress(java.lang.String address) {
        IpawsBPELProcess_pt_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcess.class.isAssignableFrom(serviceEndpointInterface)) {
                com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcessBindingStub _stub = new com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess.IpawsBPELProcessBindingStub(new java.net.URL(IpawsBPELProcess_pt_address), this);
                _stub.setPortName(getIpawsBPELProcess_ptWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("IpawsBPELProcess_pt".equals(inputPortName)) {
            return getIpawsBPELProcess_pt();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "ipawsbpelprocess_client_ep");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "IpawsBPELProcess_pt"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("IpawsBPELProcess_pt".equals(portName)) {
            setIpawsBPELProcess_ptEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
