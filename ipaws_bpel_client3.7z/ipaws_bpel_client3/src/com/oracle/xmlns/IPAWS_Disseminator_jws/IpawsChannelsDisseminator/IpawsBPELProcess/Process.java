/**
 * Process.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.oracle.xmlns.IPAWS_Disseminator_jws.IpawsChannelsDisseminator.IpawsBPELProcess;

public class Process  implements java.io.Serializable {
    private _2._1.cap.emergency.tc.names.oasis.Alert capAlertForCmac;

    private _2._1.cap.emergency.tc.names.oasis.Alert capAlert;

    private java.lang.String CMAC_message_number;

    private java.lang.String msgType;

    private java.lang.String CMAC_referenced_message_number;

    private java.lang.String CMAC_cap_alert_uri;

    private java.lang.Boolean isNWEM;

    private java.lang.Boolean isCMAC;

    private java.lang.Boolean isCMACv2;

    private java.lang.Boolean isEAS;

    private java.lang.Boolean isPUBLIC;

    private java.lang.String cogId;

    private java.lang.String userName;

    public Process() {
    }

    public Process(
           _2._1.cap.emergency.tc.names.oasis.Alert capAlertForCmac,
           _2._1.cap.emergency.tc.names.oasis.Alert capAlert,
           java.lang.String CMAC_message_number,
           java.lang.String msgType,
           java.lang.String CMAC_referenced_message_number,
           java.lang.String CMAC_cap_alert_uri,
           java.lang.Boolean isNWEM,
           java.lang.Boolean isCMAC,
           java.lang.Boolean isCMACv2,
           java.lang.Boolean isEAS,
           java.lang.Boolean isPUBLIC,
           java.lang.String cogId,
           java.lang.String userName) {
           this.capAlertForCmac = capAlertForCmac;
           this.capAlert = capAlert;
           this.CMAC_message_number = CMAC_message_number;
           this.msgType = msgType;
           this.CMAC_referenced_message_number = CMAC_referenced_message_number;
           this.CMAC_cap_alert_uri = CMAC_cap_alert_uri;
           this.isNWEM = isNWEM;
           this.isCMAC = isCMAC;
           this.isCMACv2 = isCMACv2;
           this.isEAS = isEAS;
           this.isPUBLIC = isPUBLIC;
           this.cogId = cogId;
           this.userName = userName;
    }


    /**
     * Gets the capAlertForCmac value for this Process.
     * 
     * @return capAlertForCmac
     */
    public _2._1.cap.emergency.tc.names.oasis.Alert getCapAlertForCmac() {
        return capAlertForCmac;
    }


    /**
     * Sets the capAlertForCmac value for this Process.
     * 
     * @param capAlertForCmac
     */
    public void setCapAlertForCmac(_2._1.cap.emergency.tc.names.oasis.Alert capAlertForCmac) {
        this.capAlertForCmac = capAlertForCmac;
    }


    /**
     * Gets the capAlert value for this Process.
     * 
     * @return capAlert
     */
    public _2._1.cap.emergency.tc.names.oasis.Alert getCapAlert() {
        return capAlert;
    }


    /**
     * Sets the capAlert value for this Process.
     * 
     * @param capAlert
     */
    public void setCapAlert(_2._1.cap.emergency.tc.names.oasis.Alert capAlert) {
        this.capAlert = capAlert;
    }


    /**
     * Gets the CMAC_message_number value for this Process.
     * 
     * @return CMAC_message_number
     */
    public java.lang.String getCMAC_message_number() {
        return CMAC_message_number;
    }


    /**
     * Sets the CMAC_message_number value for this Process.
     * 
     * @param CMAC_message_number
     */
    public void setCMAC_message_number(java.lang.String CMAC_message_number) {
        this.CMAC_message_number = CMAC_message_number;
    }


    /**
     * Gets the msgType value for this Process.
     * 
     * @return msgType
     */
    public java.lang.String getMsgType() {
        return msgType;
    }


    /**
     * Sets the msgType value for this Process.
     * 
     * @param msgType
     */
    public void setMsgType(java.lang.String msgType) {
        this.msgType = msgType;
    }


    /**
     * Gets the CMAC_referenced_message_number value for this Process.
     * 
     * @return CMAC_referenced_message_number
     */
    public java.lang.String getCMAC_referenced_message_number() {
        return CMAC_referenced_message_number;
    }


    /**
     * Sets the CMAC_referenced_message_number value for this Process.
     * 
     * @param CMAC_referenced_message_number
     */
    public void setCMAC_referenced_message_number(java.lang.String CMAC_referenced_message_number) {
        this.CMAC_referenced_message_number = CMAC_referenced_message_number;
    }


    /**
     * Gets the CMAC_cap_alert_uri value for this Process.
     * 
     * @return CMAC_cap_alert_uri
     */
    public java.lang.String getCMAC_cap_alert_uri() {
        return CMAC_cap_alert_uri;
    }


    /**
     * Sets the CMAC_cap_alert_uri value for this Process.
     * 
     * @param CMAC_cap_alert_uri
     */
    public void setCMAC_cap_alert_uri(java.lang.String CMAC_cap_alert_uri) {
        this.CMAC_cap_alert_uri = CMAC_cap_alert_uri;
    }


    /**
     * Gets the isNWEM value for this Process.
     * 
     * @return isNWEM
     */
    public java.lang.Boolean getIsNWEM() {
        return isNWEM;
    }


    /**
     * Sets the isNWEM value for this Process.
     * 
     * @param isNWEM
     */
    public void setIsNWEM(java.lang.Boolean isNWEM) {
        this.isNWEM = isNWEM;
    }


    /**
     * Gets the isCMAC value for this Process.
     * 
     * @return isCMAC
     */
    public java.lang.Boolean getIsCMAC() {
        return isCMAC;
    }


    /**
     * Sets the isCMAC value for this Process.
     * 
     * @param isCMAC
     */
    public void setIsCMAC(java.lang.Boolean isCMAC) {
        this.isCMAC = isCMAC;
    }


    /**
     * Gets the isCMACv2 value for this Process.
     * 
     * @return isCMACv2
     */
    public java.lang.Boolean getIsCMACv2() {
        return isCMACv2;
    }


    /**
     * Sets the isCMACv2 value for this Process.
     * 
     * @param isCMACv2
     */
    public void setIsCMACv2(java.lang.Boolean isCMACv2) {
        this.isCMACv2 = isCMACv2;
    }


    /**
     * Gets the isEAS value for this Process.
     * 
     * @return isEAS
     */
    public java.lang.Boolean getIsEAS() {
        return isEAS;
    }


    /**
     * Sets the isEAS value for this Process.
     * 
     * @param isEAS
     */
    public void setIsEAS(java.lang.Boolean isEAS) {
        this.isEAS = isEAS;
    }


    /**
     * Gets the isPUBLIC value for this Process.
     * 
     * @return isPUBLIC
     */
    public java.lang.Boolean getIsPUBLIC() {
        return isPUBLIC;
    }


    /**
     * Sets the isPUBLIC value for this Process.
     * 
     * @param isPUBLIC
     */
    public void setIsPUBLIC(java.lang.Boolean isPUBLIC) {
        this.isPUBLIC = isPUBLIC;
    }


    /**
     * Gets the cogId value for this Process.
     * 
     * @return cogId
     */
    public java.lang.String getCogId() {
        return cogId;
    }


    /**
     * Sets the cogId value for this Process.
     * 
     * @param cogId
     */
    public void setCogId(java.lang.String cogId) {
        this.cogId = cogId;
    }


    /**
     * Gets the userName value for this Process.
     * 
     * @return userName
     */
    public java.lang.String getUserName() {
        return userName;
    }


    /**
     * Sets the userName value for this Process.
     * 
     * @param userName
     */
    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Process)) return false;
        Process other = (Process) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.capAlertForCmac==null && other.getCapAlertForCmac()==null) || 
             (this.capAlertForCmac!=null &&
              this.capAlertForCmac.equals(other.getCapAlertForCmac()))) &&
            ((this.capAlert==null && other.getCapAlert()==null) || 
             (this.capAlert!=null &&
              this.capAlert.equals(other.getCapAlert()))) &&
            ((this.CMAC_message_number==null && other.getCMAC_message_number()==null) || 
             (this.CMAC_message_number!=null &&
              this.CMAC_message_number.equals(other.getCMAC_message_number()))) &&
            ((this.msgType==null && other.getMsgType()==null) || 
             (this.msgType!=null &&
              this.msgType.equals(other.getMsgType()))) &&
            ((this.CMAC_referenced_message_number==null && other.getCMAC_referenced_message_number()==null) || 
             (this.CMAC_referenced_message_number!=null &&
              this.CMAC_referenced_message_number.equals(other.getCMAC_referenced_message_number()))) &&
            ((this.CMAC_cap_alert_uri==null && other.getCMAC_cap_alert_uri()==null) || 
             (this.CMAC_cap_alert_uri!=null &&
              this.CMAC_cap_alert_uri.equals(other.getCMAC_cap_alert_uri()))) &&
            ((this.isNWEM==null && other.getIsNWEM()==null) || 
             (this.isNWEM!=null &&
              this.isNWEM.equals(other.getIsNWEM()))) &&
            ((this.isCMAC==null && other.getIsCMAC()==null) || 
             (this.isCMAC!=null &&
              this.isCMAC.equals(other.getIsCMAC()))) &&
            ((this.isCMACv2==null && other.getIsCMACv2()==null) || 
             (this.isCMACv2!=null &&
              this.isCMACv2.equals(other.getIsCMACv2()))) &&
            ((this.isEAS==null && other.getIsEAS()==null) || 
             (this.isEAS!=null &&
              this.isEAS.equals(other.getIsEAS()))) &&
            ((this.isPUBLIC==null && other.getIsPUBLIC()==null) || 
             (this.isPUBLIC!=null &&
              this.isPUBLIC.equals(other.getIsPUBLIC()))) &&
            ((this.cogId==null && other.getCogId()==null) || 
             (this.cogId!=null &&
              this.cogId.equals(other.getCogId()))) &&
            ((this.userName==null && other.getUserName()==null) || 
             (this.userName!=null &&
              this.userName.equals(other.getUserName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCapAlertForCmac() != null) {
            _hashCode += getCapAlertForCmac().hashCode();
        }
        if (getCapAlert() != null) {
            _hashCode += getCapAlert().hashCode();
        }
        if (getCMAC_message_number() != null) {
            _hashCode += getCMAC_message_number().hashCode();
        }
        if (getMsgType() != null) {
            _hashCode += getMsgType().hashCode();
        }
        if (getCMAC_referenced_message_number() != null) {
            _hashCode += getCMAC_referenced_message_number().hashCode();
        }
        if (getCMAC_cap_alert_uri() != null) {
            _hashCode += getCMAC_cap_alert_uri().hashCode();
        }
        if (getIsNWEM() != null) {
            _hashCode += getIsNWEM().hashCode();
        }
        if (getIsCMAC() != null) {
            _hashCode += getIsCMAC().hashCode();
        }
        if (getIsCMACv2() != null) {
            _hashCode += getIsCMACv2().hashCode();
        }
        if (getIsEAS() != null) {
            _hashCode += getIsEAS().hashCode();
        }
        if (getIsPUBLIC() != null) {
            _hashCode += getIsPUBLIC().hashCode();
        }
        if (getCogId() != null) {
            _hashCode += getCogId().hashCode();
        }
        if (getUserName() != null) {
            _hashCode += getUserName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Process.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", ">process"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("capAlertForCmac");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "capAlertForCmac"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "alert"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("capAlert");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "capAlert"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "alert"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CMAC_message_number");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "CMAC_message_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "msgType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CMAC_referenced_message_number");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "CMAC_referenced_message_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CMAC_cap_alert_uri");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "CMAC_cap_alert_uri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isNWEM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isNWEM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isCMAC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isCMAC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isCMACv2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isCMACv2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isEAS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isEAS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPUBLIC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "isPUBLIC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cogId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "cogId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://xmlns.oracle.com/IPAWS_Disseminator_jws/IpawsChannelsDisseminator/IpawsBPELProcess", "userName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
