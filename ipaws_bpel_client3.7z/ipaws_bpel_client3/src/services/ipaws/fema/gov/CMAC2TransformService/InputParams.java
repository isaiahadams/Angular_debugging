/**
 * InputParams.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package services.ipaws.fema.gov.CMAC2TransformService;

public class InputParams  implements java.io.Serializable {
    private _2._1.cap.emergency.tc.names.oasis.Alert alert;

    private byte[] CMAC_message_number;

    private byte[] CMAC_referenced_message_number;

    public InputParams() {
    }

    public InputParams(
           _2._1.cap.emergency.tc.names.oasis.Alert alert,
           byte[] CMAC_message_number,
           byte[] CMAC_referenced_message_number) {
           this.alert = alert;
           this.CMAC_message_number = CMAC_message_number;
           this.CMAC_referenced_message_number = CMAC_referenced_message_number;
    }


    /**
     * Gets the alert value for this InputParams.
     * 
     * @return alert
     */
    public _2._1.cap.emergency.tc.names.oasis.Alert getAlert() {
        return alert;
    }


    /**
     * Sets the alert value for this InputParams.
     * 
     * @param alert
     */
    public void setAlert(_2._1.cap.emergency.tc.names.oasis.Alert alert) {
        this.alert = alert;
    }


    /**
     * Gets the CMAC_message_number value for this InputParams.
     * 
     * @return CMAC_message_number
     */
    public byte[] getCMAC_message_number() {
        return CMAC_message_number;
    }


    /**
     * Sets the CMAC_message_number value for this InputParams.
     * 
     * @param CMAC_message_number
     */
    public void setCMAC_message_number(byte[] CMAC_message_number) {
        this.CMAC_message_number = CMAC_message_number;
    }


    /**
     * Gets the CMAC_referenced_message_number value for this InputParams.
     * 
     * @return CMAC_referenced_message_number
     */
    public byte[] getCMAC_referenced_message_number() {
        return CMAC_referenced_message_number;
    }


    /**
     * Sets the CMAC_referenced_message_number value for this InputParams.
     * 
     * @param CMAC_referenced_message_number
     */
    public void setCMAC_referenced_message_number(byte[] CMAC_referenced_message_number) {
        this.CMAC_referenced_message_number = CMAC_referenced_message_number;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InputParams)) return false;
        InputParams other = (InputParams) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.alert==null && other.getAlert()==null) || 
             (this.alert!=null &&
              this.alert.equals(other.getAlert()))) &&
            ((this.CMAC_message_number==null && other.getCMAC_message_number()==null) || 
             (this.CMAC_message_number!=null &&
              java.util.Arrays.equals(this.CMAC_message_number, other.getCMAC_message_number()))) &&
            ((this.CMAC_referenced_message_number==null && other.getCMAC_referenced_message_number()==null) || 
             (this.CMAC_referenced_message_number!=null &&
              java.util.Arrays.equals(this.CMAC_referenced_message_number, other.getCMAC_referenced_message_number())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAlert() != null) {
            _hashCode += getAlert().hashCode();
        }
        if (getCMAC_message_number() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCMAC_message_number());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCMAC_message_number(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCMAC_referenced_message_number() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCMAC_referenced_message_number());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCMAC_referenced_message_number(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InputParams.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", ">inputParams"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alert");
        elemField.setXmlName(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", "alert"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:oasis:names:tc:emergency:cap:1.2", "alert"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CMAC_message_number");
        elemField.setXmlName(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", "CMAC_message_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CMAC_referenced_message_number");
        elemField.setXmlName(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/CMAC2TransformService/", "CMAC_referenced_message_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "hexBinary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
