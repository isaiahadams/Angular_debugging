/**
 * IpawsDisseminationService_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package services.ipaws.fema.gov.IpawsDisseminationService;

public interface IpawsDisseminationService_Service extends javax.xml.rpc.Service {
    public java.lang.String getIpawsDisseminationServiceAddress();

    public services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationService_PortType getIpawsDisseminationService() throws javax.xml.rpc.ServiceException;

    public services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationService_PortType getIpawsDisseminationService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
