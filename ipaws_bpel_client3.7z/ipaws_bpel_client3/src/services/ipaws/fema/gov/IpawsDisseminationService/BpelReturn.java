/**
 * BpelReturn.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package services.ipaws.fema.gov.IpawsDisseminationService;

public class BpelReturn  implements java.io.Serializable {
    private java.lang.String cmacReturn;

    private java.lang.String nwemReturn;

    private java.lang.String easReturn;

    private java.lang.String publicReturn;

    public BpelReturn() {
    }

    public BpelReturn(
           java.lang.String cmacReturn,
           java.lang.String nwemReturn,
           java.lang.String easReturn,
           java.lang.String publicReturn) {
           this.cmacReturn = cmacReturn;
           this.nwemReturn = nwemReturn;
           this.easReturn = easReturn;
           this.publicReturn = publicReturn;
    }


    /**
     * Gets the cmacReturn value for this BpelReturn.
     * 
     * @return cmacReturn
     */
    public java.lang.String getCmacReturn() {
        return cmacReturn;
    }


    /**
     * Sets the cmacReturn value for this BpelReturn.
     * 
     * @param cmacReturn
     */
    public void setCmacReturn(java.lang.String cmacReturn) {
        this.cmacReturn = cmacReturn;
    }


    /**
     * Gets the nwemReturn value for this BpelReturn.
     * 
     * @return nwemReturn
     */
    public java.lang.String getNwemReturn() {
        return nwemReturn;
    }


    /**
     * Sets the nwemReturn value for this BpelReturn.
     * 
     * @param nwemReturn
     */
    public void setNwemReturn(java.lang.String nwemReturn) {
        this.nwemReturn = nwemReturn;
    }


    /**
     * Gets the easReturn value for this BpelReturn.
     * 
     * @return easReturn
     */
    public java.lang.String getEasReturn() {
        return easReturn;
    }


    /**
     * Sets the easReturn value for this BpelReturn.
     * 
     * @param easReturn
     */
    public void setEasReturn(java.lang.String easReturn) {
        this.easReturn = easReturn;
    }


    /**
     * Gets the publicReturn value for this BpelReturn.
     * 
     * @return publicReturn
     */
    public java.lang.String getPublicReturn() {
        return publicReturn;
    }


    /**
     * Sets the publicReturn value for this BpelReturn.
     * 
     * @param publicReturn
     */
    public void setPublicReturn(java.lang.String publicReturn) {
        this.publicReturn = publicReturn;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BpelReturn)) return false;
        BpelReturn other = (BpelReturn) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cmacReturn==null && other.getCmacReturn()==null) || 
             (this.cmacReturn!=null &&
              this.cmacReturn.equals(other.getCmacReturn()))) &&
            ((this.nwemReturn==null && other.getNwemReturn()==null) || 
             (this.nwemReturn!=null &&
              this.nwemReturn.equals(other.getNwemReturn()))) &&
            ((this.easReturn==null && other.getEasReturn()==null) || 
             (this.easReturn!=null &&
              this.easReturn.equals(other.getEasReturn()))) &&
            ((this.publicReturn==null && other.getPublicReturn()==null) || 
             (this.publicReturn!=null &&
              this.publicReturn.equals(other.getPublicReturn())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCmacReturn() != null) {
            _hashCode += getCmacReturn().hashCode();
        }
        if (getNwemReturn() != null) {
            _hashCode += getNwemReturn().hashCode();
        }
        if (getEasReturn() != null) {
            _hashCode += getEasReturn().hashCode();
        }
        if (getPublicReturn() != null) {
            _hashCode += getPublicReturn().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BpelReturn.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/IpawsDisseminationService/", ">bpelReturn"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cmacReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/IpawsDisseminationService/", "cmacReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nwemReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/IpawsDisseminationService/", "nwemReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("easReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/IpawsDisseminationService/", "easReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publicReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://gov.fema.ipaws.services/IpawsDisseminationService/", "publicReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
