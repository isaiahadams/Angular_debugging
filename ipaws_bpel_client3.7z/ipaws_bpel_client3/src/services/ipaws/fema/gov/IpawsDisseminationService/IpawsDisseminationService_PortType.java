/**
 * IpawsDisseminationService_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package services.ipaws.fema.gov.IpawsDisseminationService;

public interface IpawsDisseminationService_PortType extends java.rmi.Remote {
    public services.ipaws.fema.gov.IpawsDisseminationService.BpelReturn disseminateCAPAlert(services.ipaws.fema.gov.IpawsDisseminationService.BpelInputParams inputParams) throws java.rmi.RemoteException, services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationServiceException;
}
