package services.ipaws.fema.gov.IpawsDisseminationService;

public class IpawsDisseminationServiceProxy implements services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationService_PortType {
  private String _endpoint = null;
  private services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationService_PortType ipawsDisseminationService_PortType = null;
  
  public IpawsDisseminationServiceProxy() {
    _initIpawsDisseminationServiceProxy();
  }
  
  public IpawsDisseminationServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initIpawsDisseminationServiceProxy();
  }
  
  private void _initIpawsDisseminationServiceProxy() {
    try {
      ipawsDisseminationService_PortType = (new services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationService_ServiceLocator()).getIpawsDisseminationService();
      if (ipawsDisseminationService_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)ipawsDisseminationService_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)ipawsDisseminationService_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (ipawsDisseminationService_PortType != null)
      ((javax.xml.rpc.Stub)ipawsDisseminationService_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationService_PortType getIpawsDisseminationService_PortType() {
    if (ipawsDisseminationService_PortType == null)
      _initIpawsDisseminationServiceProxy();
    return ipawsDisseminationService_PortType;
  }
  
  public services.ipaws.fema.gov.IpawsDisseminationService.BpelReturn disseminateCAPAlert(services.ipaws.fema.gov.IpawsDisseminationService.BpelInputParams inputParams) throws java.rmi.RemoteException, services.ipaws.fema.gov.IpawsDisseminationService.IpawsDisseminationServiceException{
    if (ipawsDisseminationService_PortType == null)
      _initIpawsDisseminationServiceProxy();
    return ipawsDisseminationService_PortType.disseminateCAPAlert(inputParams);
  }
  
  
}